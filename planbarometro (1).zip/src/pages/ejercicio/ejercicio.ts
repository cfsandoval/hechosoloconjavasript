import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-ejercicio',
  templateUrl: 'ejercicio.html'
})
export class EjercicioPage {

  constructor(public navCtrl: NavController) {
  }
  
}
