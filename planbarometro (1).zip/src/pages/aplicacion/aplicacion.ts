import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-aplicacion',
  templateUrl: 'aplicacion.html'
})
export class AplicacionPage {

  constructor(public navCtrl: NavController) {
  }
  
}
